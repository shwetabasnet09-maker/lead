# NDIS Lead Finder

NDIS Lead Finder is a Django-based internal lead-intelligence and CRM application for Australian disability and home-care businesses. It discovers **publicly posted service requests** from sources that have been reviewed and approved for crawling. It does not identify anonymous search-engine users and does not bypass authentication, CAPTCHAs, robots rules, or access controls.

## Included in the MVP

- Custom responsive staff dashboard using Django templates.
- Django Unfold administration for sources, keywords, locations, users, and system records.
- RSS/Atom, configurable HTML, and optional Selenium source adapters.
- Per-source permission review gates, crawl delay, run logs, and failure visibility.
- Rule-based intent classification with optional OpenAI-compatible AI enrichment using an encrypted bring-your-own key.
- Australian service taxonomy, locations, freshness rules, false-positive filtering, and duplicate detection.
- Lead claim protection, CRM statuses, notes, reminders, audit records, notifications, reports, and CSV export.
- SQLite MVP with sequential scraper locking and a documented future database migration path.
- Daily backups, summary email command, automated tests, and cPanel deployment files.

## What it deliberately does not do

- It cannot reveal who privately searched Google or another directory.
- It does not scrape private Facebook groups, private profiles, private messages, or login-protected content.
- It does not send automatic marketing emails, SMS, calls, or WhatsApp messages.
- It does not activate a source until its terms and robots policy have been reviewed.
- It does not copy full pages. It stores a short relevant snippet and source URL.

## Local setup on Windows

```powershell
python -m venv .venv
.venv\Scripts\Activate.ps1
python -m pip install -r requirements.txt
Copy-Item .env.example .env
```

Set environment variables from `.env` in your terminal or IDE. This project intentionally does not silently load `.env` in production.

```powershell
python manage.py migrate
python manage.py createsuperuser
python manage.py seed_initial_data --username admin
python manage.py runserver
```

Open:

- Staff application: `http://127.0.0.1:8000/`
- Unfold administration: `http://127.0.0.1:8000/admin/`

## Safe source setup

1. Open **Administration → Sources → Add source**.
2. Record the exact source domain and search/feed URL template.
3. Review the site's terms, robots policy, API/feed options, and permitted request rate.
4. Select the correct source type.
5. For HTML/Selenium, provide selectors such as:

```json
{
  "item": ".search-result",
  "title": "h2",
  "link": "h2 a",
  "snippet": ".description",
  "date": "time",
  "name": ".author",
  "phone": ".phone",
  "email": ".email"
}
```

6. Mark `robots reviewed`, `terms reviewed`, and `review status = Approved` only after review.
7. Enable the source and test it with:

```powershell
python manage.py run_scrapers --source SOURCE_ID --profile PROFILE_ID
```

The search URL template supports `{query}`, `{location}`, and `{page}`. It must remain on the approved base domain.

## Scheduled commands

Run every six hours:

```text
python manage.py run_scrapers
```

Run daily:

```text
python manage.py backup_database
python manage.py send_daily_summary
```

## Selenium

Selenium is disabled by default. Set `SELENIUM_ENABLED=true` only after confirming that the host provides a compatible Chrome/Chromium binary and permits headless browser processes. The scraper uses explicit waits and always quits the driver.

## Optional AI

The default classifier does not require an AI API. To add an OpenAI-compatible service:

1. Generate and set `FIELD_ENCRYPTION_KEY`.
2. Add an AI configuration in Unfold admin.
3. Enter the base URL, model, and API key.
4. Enable it.

If the AI call fails, the deterministic classifier remains active. AI output cannot initiate outreach or infer diagnosis, eligibility, funding, or sensitive personal information.

## Testing and production checks

```powershell
python manage.py test
python manage.py check
python manage.py check --deploy
```

Production warnings about HSTS/SSL are expected until the real domain and TLS settings are applied. See [DEPLOYMENT_BABAL.md](DEPLOYMENT_BABAL.md).
