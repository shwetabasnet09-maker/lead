from django.urls import path

from . import views

urlpatterns = [
    path("", views.dashboard, name="dashboard"),
    path("leads/", views.lead_list, name="lead-list"),
    path("leads/export/", views.export_leads, name="lead-export"),
    path("leads/<int:pk>/", views.lead_detail, name="lead-detail"),
    path("leads/<int:pk>/claim/", views.claim_lead, name="lead-claim"),
    path("leads/<int:pk>/release/", views.release_lead, name="lead-release"),
    path("leads/<int:pk>/update/", views.update_lead, name="lead-update"),
    path("reports/", views.reports, name="reports"),
    path("notifications/", views.notifications, name="notifications"),
]
