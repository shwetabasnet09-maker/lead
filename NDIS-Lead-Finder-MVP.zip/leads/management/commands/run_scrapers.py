from pathlib import Path

from django.conf import settings
from django.core.management.base import BaseCommand, CommandError
from django.utils import timezone

from leads.models import SearchProfile, Source
from leads.services import archive_stale_leads, run_source_profile


class Command(BaseCommand):
    help = "Run approved sources sequentially. Designed for cPanel cron and SQLite-safe execution."

    def add_arguments(self, parser):
        parser.add_argument("--source", type=int, help="Run one source ID")
        parser.add_argument("--profile", type=int, help="Run one search profile ID")

    def handle(self, *args, **options):
        lock_path = settings.BASE_DIR / ".scraper.lock"
        if lock_path.exists():
            try:
                age = timezone.now().timestamp() - lock_path.stat().st_mtime
            except OSError:
                age = 0
            if age < 60 * 60 * 3:
                raise CommandError("Another scraper run appears active. Remove .scraper.lock only after verifying no run is active.")
            lock_path.unlink(missing_ok=True)
        lock_path.write_text(str(timezone.now()), encoding="utf-8")
        try:
            sources = Source.objects.filter(enabled=True, review_status=Source.ReviewStatus.APPROVED, robots_reviewed=True, terms_reviewed=True)
            profiles = SearchProfile.objects.filter(active=True).prefetch_related("keywords")
            if options["source"]:
                sources = sources.filter(pk=options["source"])
            if options["profile"]:
                profiles = profiles.filter(pk=options["profile"])
            for source in sources:
                for profile in profiles:
                    self.stdout.write(f"Running {source} / {profile}")
                    run = run_source_profile(source, profile)
                    style = self.style.SUCCESS if run.status == run.Status.SUCCESS else self.style.ERROR
                    self.stdout.write(style(f"{run.status}: {run.leads_created} new lead(s), {run.duplicates_found} duplicate(s)"))
            archived = archive_stale_leads()
            self.stdout.write(self.style.SUCCESS(f"Archived {archived} stale lead(s)."))
        finally:
            lock_path.unlink(missing_ok=True)
