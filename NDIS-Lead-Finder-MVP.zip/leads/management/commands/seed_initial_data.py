from django.contrib.auth.models import User
from django.core.management.base import BaseCommand
from django.utils.text import slugify

from leads.models import Keyword, Membership, Organisation, SearchProfile, ServiceCategory, Source


CATEGORIES = {
    "Home care / in-home support": ["home care", "homecare", "in-home care", "in home support"],
    "Personal care": ["personal care", "daily personal activities"],
    "Support worker": ["support worker", "disability support worker"],
    "Community participation": ["community participation", "social participation"],
    "Domestic assistance / cleaning": ["domestic assistance", "ndis cleaning", "home cleaning"],
    "Nursing": ["home care nurse", "community nursing", "ndis nurse"],
    "Day programs / day care": ["day program", "day care"],
    "Respite / Short-Term Accommodation": ["respite", "short term accommodation", "sta"],
    "Supported Independent Living": ["supported independent living", "sil"],
    "Specialist Disability Accommodation": ["specialist disability accommodation", "sda"],
    "Transport": ["ndis transport", "accessible transport"],
    "Meal preparation": ["meal preparation", "meal support"],
    "Occupational therapy": ["occupational therapist", "occupational therapy", "ot"],
    "Physiotherapy": ["physiotherapy", "physiotherapist"],
    "Speech therapy": ["speech therapy", "speech pathologist"],
    "Psychology / counselling": ["psychologist", "psychology", "counselling"],
    "Behaviour support": ["behaviour support", "positive behaviour support"],
    "Support coordination": ["support coordinator", "support coordination"],
    "Plan management": ["plan manager", "plan management"],
    "Home modifications": ["home modification", "accessible home modification"],
    "Other service request": [],
}


class Command(BaseCommand):
    help = "Create the default organisation, taxonomy, Melbourne search profile, and disabled example sources."

    def add_arguments(self, parser):
        parser.add_argument("--username", default="admin")

    def handle(self, *args, **options):
        organisation, _ = Organisation.objects.get_or_create(slug="default", defaults={"name": "NDIS Lead Finder"})
        profile, _ = SearchProfile.objects.get_or_create(
            organisation=organisation,
            name="Melbourne and Victoria",
            defaults={"states": "VIC", "locations": "Melbourne\nDandenong\nGeelong", "radius_km": 50},
        )
        for name, synonyms in CATEGORIES.items():
            category, _ = ServiceCategory.objects.get_or_create(
                name=name,
                defaults={"slug": slugify(name)[:50], "synonyms": "\n".join(synonyms)},
            )
            for term in synonyms[:3]:
                Keyword.objects.get_or_create(profile=profile, term=term, kind=Keyword.Kind.POSITIVE, defaults={"category": category, "generated": True})
        for term in ["job", "vacancy", "hiring", "course", "training", "we provide", "our services"]:
            Keyword.objects.get_or_create(profile=profile, term=term, kind=Keyword.Kind.NEGATIVE)
        for name, url in [
            ("MyCareSpace reference", "https://mycarespace.com.au/"),
            ("Clickability reference", "https://clickability.com.au/"),
            ("Karista reference", "https://www.karista.com.au/"),
            ("MySolas reference", "https://www.mysolas.com.au/"),
        ]:
            Source.objects.get_or_create(
                name=name,
                defaults={"source_type": Source.SourceType.HTML, "base_url": url, "search_url_template": url, "enabled": False},
            )
        user = User.objects.filter(username=options["username"]).first()
        if user:
            Membership.objects.get_or_create(organisation=organisation, user=user, defaults={"role": Membership.Role.OWNER})
        self.stdout.write(self.style.SUCCESS("Initial taxonomy and safe disabled reference sources created."))
