from django.conf import settings

from .models import Notification


def app_context(request):
    unread = 0
    if request.user.is_authenticated:
        unread = Notification.objects.filter(user=request.user, read_at__isnull=True).count()
    return {"APP_NAME": settings.APP_NAME, "unread_notification_count": unread}
