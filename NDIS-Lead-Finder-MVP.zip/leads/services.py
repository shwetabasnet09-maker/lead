from __future__ import annotations

import json
from datetime import timedelta

import requests
from django.db import IntegrityError, transaction
from django.urls import reverse
from django.utils import timezone

from .classifier import classify_record, find_possible_duplicate
from .models import (
    AIConfiguration,
    AuditLog,
    Lead,
    Notification,
    Organisation,
    ScrapeRun,
    SearchProfile,
    Source,
)
from .scrapers import ScrapedRecord, build_search_url, polite_pause, scrape_source


def default_organisation() -> Organisation:
    organisation, _ = Organisation.objects.get_or_create(slug="default", defaults={"name": "NDIS Lead Finder"})
    return organisation


def optionally_enrich_with_ai(organisation: Organisation, record: ScrapedRecord, classification: dict) -> dict:
    try:
        config: AIConfiguration = organisation.ai_configuration
    except AIConfiguration.DoesNotExist:
        return classification
    if not config.enabled or not config.base_url or not config.model:
        return classification
    api_key = config.get_api_key()
    if not api_key:
        return classification
    prompt = {
        "task": "Classify a public Australian disability/home-care service request. Do not infer diagnosis or sensitive data.",
        "allowed_labels": ["likely", "review", "job", "provider_ad", "location_unknown"],
        "record": {"title": record.title, "snippet": record.snippet},
        "current": classification,
        "output": "Return JSON only with label, lead_type, service_category_name, suburb, state, postcode, and reason.",
    }
    try:
        response = requests.post(
            config.base_url.rstrip("/") + "/chat/completions",
            headers={"Authorization": f"Bearer {api_key}", "Content-Type": "application/json"},
            json={
                "model": config.model,
                "temperature": 0,
                "messages": [{"role": "user", "content": json.dumps(prompt)}],
                "response_format": {"type": "json_object"},
            },
            timeout=25,
        )
        response.raise_for_status()
        content = response.json()["choices"][0]["message"]["content"]
        result = json.loads(content)
        allowed = {"likely", "review", "job", "provider_ad", "location_unknown"}
        if result.get("label") in allowed:
            classification.update({k: v for k, v in result.items() if k in classification})
    except Exception:
        return classification
    return classification


def ingest_record(source: Source, profile: SearchProfile, record: ScrapedRecord) -> tuple[Lead, bool, bool]:
    organisation = profile.organisation
    classified = classify_record(record.title, record.snippet, profile, record.published_at)
    values = {
        "label": classified.label,
        "lead_type": classified.lead_type,
        "state": classified.state,
        "postcode": classified.postcode,
        "suburb": classified.suburb,
        "location_unknown": classified.location_unknown,
    }
    values = optionally_enrich_with_ai(organisation, record, values)
    duplicate = find_possible_duplicate(record.title, record.snippet, record.public_phone, record.public_email)
    content_hash = Lead.make_hash(record.title, record.snippet, record.public_phone, record.public_email)
    defaults = {
        "organisation": organisation,
        "external_id": record.external_id[:255],
        "title": record.title[:500],
        "snippet": record.snippet,
        "public_name": record.public_name[:200],
        "public_phone": record.public_phone[:80],
        "public_email": record.public_email if "@" in record.public_email else "",
        "service_category": classified.category,
        "published_at": record.published_at,
        "last_checked_at": timezone.now(),
        "content_hash": content_hash,
        "duplicate_of": duplicate,
        **values,
    }
    if duplicate:
        defaults["label"] = Lead.Label.DUPLICATE
    try:
        with transaction.atomic():
            lead, created = Lead.objects.get_or_create(source=source, source_url=record.url, defaults=defaults)
    except IntegrityError:
        lead = Lead.objects.get(source=source, source_url=record.url)
        created = False
    if not created:
        lead.last_checked_at = timezone.now()
        lead.source_available = True
        lead.save(update_fields=["last_checked_at", "source_available", "updated_at"])
    elif lead.label == Lead.Label.LIKELY:
        for membership in organisation.memberships.filter(active=True).select_related("user"):
            Notification.objects.create(
                user=membership.user,
                title="New likely service request",
                message=lead.title,
                url=reverse("lead-detail", args=[lead.pk]),
            )
    return lead, created, bool(duplicate)


def run_source_profile(source: Source, profile: SearchProfile) -> ScrapeRun:
    run = ScrapeRun.objects.create(source=source, profile=profile)
    try:
        keywords = profile.keywords.filter(kind="positive", enabled=True)
        locations = profile.location_terms() or [""]
        for keyword in keywords:
            for location in locations:
                for page in range(1, source.max_pages + 1):
                    url = build_search_url(source, keyword.term, location, page)
                    records = scrape_source(source, url)
                    run.pages_fetched += 1
                    run.records_seen += len(records)
                    for record in records:
                        _, created, duplicate = ingest_record(source, profile, record)
                        run.leads_created += int(created)
                        run.duplicates_found += int(duplicate)
                    run.save(update_fields=["pages_fetched", "records_seen", "leads_created", "duplicates_found", "updated_at"])
                    polite_pause(source)
        run.status = ScrapeRun.Status.SUCCESS
        source.last_error = ""
    except Exception as exc:
        run.status = ScrapeRun.Status.FAILED
        run.error = str(exc)
        source.last_error = str(exc)
    finally:
        run.finished_at = timezone.now()
        source.last_checked_at = timezone.now()
        source.save(update_fields=["last_checked_at", "last_error", "updated_at"])
        run.save(update_fields=["status", "error", "finished_at", "updated_at"])
    return run


def archive_stale_leads(days: int = 90) -> int:
    cutoff = timezone.now() - timedelta(days=days)
    return Lead.objects.filter(discovered_at__lt=cutoff, archived_at__isnull=True).exclude(
        status__in=[Lead.Status.CONVERTED, Lead.Status.DO_NOT_CONTACT]
    ).update(status=Lead.Status.ARCHIVED, archived_at=timezone.now())
