from django import forms

from .models import Lead


class LeadUpdateForm(forms.ModelForm):
    note = forms.CharField(widget=forms.Textarea(attrs={"rows": 4, "placeholder": "Add an internal note…"}), required=False)

    class Meta:
        model = Lead
        fields = ["status", "follow_up_at"]
        widgets = {"follow_up_at": forms.DateTimeInput(attrs={"type": "datetime-local"}, format="%Y-%m-%dT%H:%M")}

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.fields["follow_up_at"].input_formats = ["%Y-%m-%dT%H:%M"]


class LeadFilterForm(forms.Form):
    q = forms.CharField(required=False, label="Search", widget=forms.TextInput(attrs={"placeholder": "Title, snippet, location or contact"}))
    status = forms.ChoiceField(required=False, choices=[("", "All statuses"), *Lead.Status.choices])
    label = forms.ChoiceField(required=False, choices=[("", "All labels"), *Lead.Label.choices])
    claimed = forms.ChoiceField(required=False, choices=[("", "All leads"), ("mine", "Claimed by me"), ("unclaimed", "Unclaimed")])
    date_from = forms.DateField(required=False, widget=forms.DateInput(attrs={"type": "date"}))
    date_to = forms.DateField(required=False, widget=forms.DateInput(attrs={"type": "date"}))
